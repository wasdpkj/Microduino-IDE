
/*
 * Zigduino
 * http://www.logos-electro.com/zigduino
 */
 
#define ZIGDUINO                (0xa1)
